﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SinValidation.Models
{
    public class SocialInsuranceNumber
    {
        [Required(ErrorMessage = "Please enter a SIN. Format: 555666777")]
        [Display(Name = "Social Insurance Number (Format - 555666777): ")]
        public int Number { get; set; }

        public string Result { get; set; }
    }
}