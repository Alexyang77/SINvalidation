﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SinValidation.Models;

namespace SinValidation.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // GET: Home  
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Validate()
        {
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Validate(SocialInsuranceNumber input)
        {
            int sin = input.Number;
            String str = sin.ToString();
            if(str.Length != 9)
            {
                ModelState.AddModelError(string.Empty, "Length of SIN must be 11. Format: 555-666-777");
                input.Result = "Invalid SIN";
            } 

            if(!IsCanadianSocialInsuranceNumber(sin))
            {
                ModelState.AddModelError(string.Empty, "");
                input.Result = "Invalid SIN";
            } else
            {
                input.Result = "Valid SIN";
            }
            
            return View("Index", input);
        }
        public static bool IsCanadianSocialInsuranceNumber(int sin)
        {
            if (sin < 0 || sin > 999999998) return false;

            int checksum = 0;
            for (int i = 4; i != 0; i--)
            {
                checksum += sin % 10;
                sin /= 10;

                int addend = 2 * (sin % 10); if (addend >= 10) addend -= 9;
                checksum += addend;
                sin /= 10;
            }

            return (checksum + sin) % 10 == 0;
        }
    }
}
